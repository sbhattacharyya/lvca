# LVCA
## Lightweight Verifiable Cognitive Architecture
