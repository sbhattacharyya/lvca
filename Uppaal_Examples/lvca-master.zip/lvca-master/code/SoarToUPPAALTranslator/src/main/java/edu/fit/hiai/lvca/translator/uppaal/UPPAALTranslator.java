package edu.fit.hiai.lvca.translator.uppaal;

public class UPPAALTranslator
{
    public static void main(String[] args)
    {

    }
}
