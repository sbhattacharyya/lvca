#!/bin/bash
sudo apt-get install python-pygame
sudo pip install gTTS
